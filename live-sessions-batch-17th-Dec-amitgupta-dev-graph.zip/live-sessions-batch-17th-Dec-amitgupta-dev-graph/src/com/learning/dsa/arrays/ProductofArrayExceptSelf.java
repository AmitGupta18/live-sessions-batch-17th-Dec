package com.learning.dsa.arrays;

import java.util.Arrays;

public class ProductofArrayExceptSelf {
    public static void main(String[] args) {
        System.out.println(Arrays.toString(productExceptSelf(new int[]{1, 2, 3, 4})));
    }

    private static int[] productExceptSelf(int[] nums) {
        int[] result = new int[nums.length];
        int holder = 1;

        // set the right product in result arr
        for (int i = nums.length - 1; i >= 0; i--) {
            result[i] = holder;
            holder *= nums[i];
        }

        holder = 1;
        // multiple each value of right product array with left element's product
        for (int i = 0; i < nums.length; i++) {
            result[i] *= holder;
            holder *= nums[i];
        }

        return result;
    }
}
