package com.learning.dsa.arrays;

import java.util.Arrays;

public class SortArray012 {
    public static void main(String[] args) {
        int[] nums = new int[]{2,0,2,1,1,0};
        int zeroIdx = 0;
        int twoIdx = nums.length - 1;
        int i = 0;

        while (i <= twoIdx) {
            if(nums[i] == 0) {
                swap(nums, i, zeroIdx++);
            } else if (nums[i] == 2) {
                swap(nums, i, twoIdx--);
                i--;
            }
            i++;
        }
    }

    private static void swap(int[] nums, int firstIdx, int secondIdx) {
        int temp = nums[firstIdx];
        nums[firstIdx] = nums[secondIdx];
        nums[secondIdx] = temp;
    }
}
