package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.List;

public class HourglassSum {
    public static void main(String[] args) {
        System.out.println(hourglassSum(Arrays.asList(
                Arrays.asList(-9, -9, -9, 1, 1, 1),
                Arrays.asList(0, -9, 0, 4, 3, 2),
                Arrays.asList(-9, -9, -9, 1, 2, 3),
                Arrays.asList(0, 0, 8, 6, 6, 0),
                Arrays.asList(0, 0, 0, -2, 0, 0),
                Arrays.asList(0, 0, 1, 2, 4, 0)
        )));
    }

    private static int hourglassSum(List<List<Integer>> arr) {
        int largestSum = Integer.MIN_VALUE;
        for (int i = 0; i < arr.size() - 2; i++) {
            for (int j = 0; j < arr.get(0).size() - 2; j++) {
                List<Integer> firstRow = arr.get(i);
                List<Integer> secondRow = arr.get(i + 1);
                List<Integer> thirdRow = arr.get(i + 2);

                int sum = firstRow.get(j) + firstRow.get(j + 1) + firstRow.get(j + 2)
                        + secondRow.get(j + 1)
                        + thirdRow.get(j) + thirdRow.get(j + 1) + thirdRow.get(j + 2);

                largestSum = Math.max(sum, largestSum);
            }
        }
        return largestSum;
    }
}
