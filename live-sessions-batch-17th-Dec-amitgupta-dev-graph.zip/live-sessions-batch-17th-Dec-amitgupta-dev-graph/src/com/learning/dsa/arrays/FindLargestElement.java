package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.List;

public class FindLargestElement {
    public static void main(String[] args) {
        System.out.println(largestElement(5, Arrays.asList(30, 10, 25, 11, 20)));
    }

    private static int largestElement(int n, List<Integer> arr) {
        int max = Integer.MIN_VALUE;
        for(Integer num: arr) {
            max = Math.max(max, num);
        }
        return max;
    }
}
