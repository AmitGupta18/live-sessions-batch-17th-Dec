package com.learning.dsa.arrays;

import java.util.Arrays;

public class NextPermutation8 {
    public static void main(String[] args) {
        System.out.println(Arrays.toString(nextPermutation(new int[] {0,1,2,5,3,3,0})));
    }

    private static int[] nextPermutation(int[] nums) {
        int idx = nums.length - 2;

        // first index from right, such that A[i] < A[i + 1].
        while(idx >= 0) {
            if (nums[idx] < nums[idx+1]) {
                break;
            }
            idx--;
        }

        // first element from right, greater than num[idx]
        if (idx >= 0) {
            for(int i = nums.length - 1; i >=0; i--) {
                if (nums[i] > nums[idx]) {
                    swap(nums, i, idx);
                    break;
                }
            }
        }

        reverse(nums, idx+1, nums.length-1);
        return nums;
    }

    private static void reverse(int[] nums, int start, int end) {
        while(start <= end) {
            swap(nums, start++, end--);
        }
    }

    private static void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
}
