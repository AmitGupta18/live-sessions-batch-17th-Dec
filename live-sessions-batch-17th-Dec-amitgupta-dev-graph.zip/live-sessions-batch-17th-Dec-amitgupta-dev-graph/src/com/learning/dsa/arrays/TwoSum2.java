package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TwoSum2 {
    public static void main(String[] args) {
        System.out.println(twoSum(9, 4, Arrays.asList(2, 7, 11, 15)));
    }

    private static List<Integer> twoSum(int target, int n, List<Integer> arr) {
        int left = 0, right = n - 1;
        while (left < right) {
            int sum = arr.get(left) + arr.get(right);
            if (sum == target) {
                break;
            }
            if (sum < target) {
                left++;
            } else {
                right--;
            }
        }
        return Arrays.asList(left + 1, right + 1);
    }
}
