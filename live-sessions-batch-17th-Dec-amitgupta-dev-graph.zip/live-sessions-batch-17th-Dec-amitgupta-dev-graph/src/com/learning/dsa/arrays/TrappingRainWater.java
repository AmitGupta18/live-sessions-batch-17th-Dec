package com.learning.dsa.arrays;

public class TrappingRainWater {
    public static void main(String[] args) {
        System.out.println(trap(new int[]{0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1}));
    }

    private static int trap(int[] height) {
        int length = height.length;
        int[] left = new int[length];
        int[] right = new int[length];

        left[0] = 0;
        int max = height[0];
        for (int i = 1; i < length; i++) {
            left[i] = max;
            max = Math.max(height[i], max);
        }

        right[length - 1] = 0;
        max = height[length - 1];
        for (int i = length - 2; i >= 0; i--) {
            right[i] = max;
            max = Math.max(height[i], max);
        }

        int result = 0;
        for (int i=0; i < length; i++) {
            int count = Math.min(left[i], right[i]) - height[i];
            if (count > 0) {
                result += count;
            }
        }

        return result;
    }
}
