package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ReverseString {
    public static void main(String[] args) {
        List<Character> arr = "hello".chars().mapToObj(c -> (char) c).collect(Collectors.toList());
        reverseString(arr.size(), arr);
        System.out.println(arr);
    }

    private static void reverseString(int n, List<Character> arr) {
        // Write your code here
        int i = 0, j = n - 1;
        while (i < j) {
            Character temp = arr.get(i);
            arr.set(i++, arr.get(j));
            arr.set(j--, temp);
        }
    }
}
