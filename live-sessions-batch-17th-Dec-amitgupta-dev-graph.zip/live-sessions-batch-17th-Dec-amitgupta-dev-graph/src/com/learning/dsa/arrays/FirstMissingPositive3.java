package com.learning.dsa.arrays;

public class FirstMissingPositive3 {
    public static void main(String[] args) {
        System.out.println(firstMissingPositive(new int[]{1,1}));
    }

    private static int firstMissingPositive(int[] nums) {
        // Replace negative values to 0
        for(int i = 0; i < nums.length; i++) {
            if (nums[i] < 0) {
                nums[i] = 0;
            }
        }

        // Get the value of each element, go to that index and convert value to -ve
        for(int i = 0; i<nums.length; i++) {
            // consider only inbound indexes
            if (Math.abs(nums[i]) == 0 || Math.abs(nums[i]) > nums.length) {
                continue;
            }

            int index = Math.abs(nums[i]) - 1;
            // if value at index is 0, replace it with negative of current value, instead of value at that index
            if (nums[index] == 0) {
                nums[index] = -1 * Math.abs(nums[i]);
            } else {
                // convert value at index to its negative
                nums[index] = -1 * Math.abs(nums[index]);
            }
        }

        // now values at all the existing indexes are -ve, and +ve for others
        for(int i = 0; i< nums.length; i++) {
            if(nums[i] >= 0) {
                return i+1;
            }
        }

        return nums.length+1;
    }
}
