package com.learning.dsa.graphs.djkistra;

import java.util.LinkedList;
import java.util.Queue;

/*
 *  https://practice.geeksforgeeks.org/problems/shortest-path-in-a-binary-maze-1655453161/1
 */

public class ShortestPathInBinaryMaze {
    static class Node {
        int x, y, dist;

        Node(int x, int y, int dist) {
            this.x = x;
            this.y = y;
            this.dist = dist;
        }
    }

    public static void main(String[] args) {
        int[][] grid = new int[][]{
                {1, 1, 1, 1},
                {1, 1, 0, 1},
                {1, 1, 1, 1},
                {1, 1, 0, 0},
                {1, 0, 0, 1}};
        System.out.println(shortestPath(grid, new int[]{0, 1}, new int[]{2, 2}));
    }

    static int shortestPath(int[][] grid, int[] source, int[] destination) {
        int[][] matrix = new int[grid.length][grid[0].length];

        for (int i = 0; i<grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                matrix[i][j] = Integer.MAX_VALUE;
            }
        }

        return djkistraAlgo(grid, matrix, source, destination);
    }

    private static int djkistraAlgo(int[][] grid, int[][] matrix, int[] source, int[] destination) {
        int i = source[0], j = source[1];
        matrix[i][j] = 0;

        Queue<Node> queue = new LinkedList<>();
        queue.add(new Node(i, j, 0));


        while(!queue.isEmpty()) {
            Node temp = queue.remove();

            if(temp.x == destination[0] && temp.y == destination[1]) {
                return temp.dist;
            }
            int[][] directions = new int[][]{{temp.x, temp.y+1}, {temp.x, temp.y-1}, {temp.x+1, temp.y}, {temp.x-1, temp.y}};
            for(int[] direction: directions) {
                int x = direction[0];
                int y = direction[1];
                if(checkBoundaries(x, y, grid.length, grid[0].length) && grid[x][y] > 0) {
                    int newDist = temp.dist +1;
                    if(newDist < matrix[x][y]) {
                        queue.add(new Node(x, y, newDist));
                        matrix[x][y] = newDist;
                    }
                }
            }
        }
        return -1;
    }

    private static boolean checkBoundaries(int i, int j, int m, int n) {
        return ((i >= 0) && (j >= 0) && (i<m) && (j<n));
    }
}
