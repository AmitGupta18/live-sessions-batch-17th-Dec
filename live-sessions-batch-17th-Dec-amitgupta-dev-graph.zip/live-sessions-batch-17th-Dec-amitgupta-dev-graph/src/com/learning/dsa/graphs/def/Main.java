package com.learning.dsa.graphs.def;

import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Graph graph = new Graph();
        graph.signUp("A");
        graph.signUp("B");
        graph.signUp("C");
        graph.signUp("D");
        graph.signUp("E");
        graph.signUp("F");
        graph.signUp("G");
        graph.signUp("H");
        graph.signUp("I");
        graph.printGraph();

        graph.sendRequest("A", "B");
        graph.sendRequest("A", "C");
        graph.sendRequest("A", "D");
        graph.sendRequest("A", "E");

        graph.sendRequest("B", "F");
        graph.sendRequest("C", "H");
        graph.sendRequest("D", "I");
        graph.sendRequest("E", "G");
        graph.printGraph();

        System.out.println("BFS");
        graph.bfs("A");


        System.out.println("DFS");
        Set<Node> visited = new HashSet<>();
        graph.dfs("A", visited);
    }
}
