package com.learning.dsa.graphs.def;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Node {
    String data;
    List<Node> connections = new ArrayList<>();

    public Node(String data) {
        this.data = data;
    }

    public Node(String data, List<Node> connections) {
        this.data = data;
        this.connections = connections;
    }

    @Override
    public String toString() {
        return "Node{" +
                "data='" + data + '\'' +
                ", connections=" + connections.stream().map(node -> node.data).collect(Collectors.toList()) +
                '}';
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public List<Node> getConnections() {
        return connections;
    }

    public void setConnections(List<Node> connections) {
        this.connections = connections;
    }
}
