package com.learning.dsa.graphs.def;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Graph {
    private Map<String, Node> vertices = new HashMap<>();

    public boolean signUp(String userName) {
        if(vertices.containsKey(userName)) {
            return false;
        }
        vertices.put(userName, new Node(userName));
        System.out.println("Signed up " +userName + " successfully");
        return true;
    }

    public List<String> getFriends(String userName) {
        return vertices.get(userName).connections.stream().map(node -> node.data).collect(Collectors.toList());
    }

    public boolean deleteAccount(String userName) {
        if(!vertices.containsKey(userName)) {
            System.out.println(userName + " not found");
            return false;
        }

        Node nodeToRemove = vertices.remove(userName);
        List<Node> connections = nodeToRemove.connections;
        connections.stream().forEach(node -> node.connections.remove(nodeToRemove));
        System.out.println("Deleted user " +userName + " Successfully");
        return true;
    }

    public void sendRequest(String from, String to) {
        if (!(vertices.containsKey(from) && vertices.containsKey(to))) {
            System.out.println("user not found");
            return;
        }

        if(vertices.get(from).connections.contains(vertices.get(to))) {
            System.out.println("Already a friend");
            return;
        }
        vertices.get(from).connections.add(vertices.get(to));
        vertices.get(to).connections.add(vertices.get(from));
    }

    public boolean removeFriend(String from, String to) {
        if(!(vertices.containsKey(from) && vertices.containsKey(to))) {
            System.out.println("User not found");
            return false;
        }
        vertices.get(from).connections.remove(vertices.get(to));
        vertices.get(to).connections.remove(vertices.get(from));
        return true;
    }

    public Node getNodeByValue(String username) {
        return vertices.get(username);
    }

    public void printGraph() {
        vertices.entrySet().stream().forEach(System.out::println);
    }

    public void bfs(String start) {
        if (!vertices.containsKey(start)) {
            return;
        }

        Node root = vertices.get(start);
        LinkedList<Node> queue = new LinkedList<>();
        Set<Node> visited = new HashSet<>();
        queue.add(root);
        visited.add(root);
        while(!queue.isEmpty()) {
            Node curr = queue.remove();
            System.out.println(curr.data);
            for(Node friend: curr.connections) {
                if (visited.contains(friend)) {
                    continue;
                }
                visited.add(friend);
                queue.add(friend);
            }
        }
    }

    public void dfs(String start, Set<Node> visited) {
        if (!vertices.containsKey(start)) {
            return;
        }

        Node root = vertices.get(start);

        System.out.println(root.data);
        visited.add(root);

        for(Node friend : root.connections) {
            if(visited.contains(friend)) {
                continue;
            }
            visited.add(friend);
            dfs(friend.data, visited);
        }
    }
}
