package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.List;

public class PascalTriangle23 {
    public static void main(String[] args) {
        System.out.println(generate(5));
    }

    private static List<List<Integer>> generate(int n) {
        int[][] result = new int[n][];
        for (int i = 0; i < n; i++) {
            int[] row = new int[i + 1];
            row[0] = 1;
            row[i] = 1;
            for (int j = 1; j < i; j++) {
                row[j] = result[i - 1][j - 1] + result[i - 1][j];
            }
            result[i] = row;
        }
        return (List) Arrays.asList(result);
    }
}
