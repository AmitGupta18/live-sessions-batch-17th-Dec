package com.learning.dsa.arrays;

import java.util.HashSet;
import java.util.Set;

public class LongestUniqueCharSubstr {
    public static void main(String[] args) {
        String str = "abcabcbb";
        System.out.println(calculateLongestSubstring(str));
    }

    private static int calculateLongestSubstring(String str) {
        int i = 0, j = 0;
        int maxlength = 0;
        Set<Character> characters = new HashSet<>();
        while (i < str.length() && j < str.length()) {
            if (!characters.contains(str.charAt(j))) {
                characters.add(str.charAt(j));
                j++;
                maxlength = Math.max(maxlength, (j - i));
            } else {
                characters.remove(str.charAt(i));
                i++;
            }
        }
        return maxlength;
    }
}
