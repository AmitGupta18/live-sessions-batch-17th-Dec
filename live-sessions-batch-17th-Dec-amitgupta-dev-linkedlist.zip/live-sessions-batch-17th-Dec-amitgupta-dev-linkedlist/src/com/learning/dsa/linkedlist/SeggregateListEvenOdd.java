package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class SeggregateListEvenOdd {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);

        SinglyLinkedList llist1 = new SinglyLinkedList();
        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist1.insertNode(llistItem);
        }

        SinglyLinkedList.printSinglyLinkedList(segregateLLEvenOdd(llist1.head));

        scanner.close();
    }

    public static SinglyLinkedListNode segregateLLEvenOdd(SinglyLinkedListNode start) {
        SinglyLinkedListNode evenListNode = new SinglyLinkedListNode(0);
        SinglyLinkedListNode evenTemp = evenListNode;
        SinglyLinkedListNode oddListNode = new SinglyLinkedListNode(0);
        SinglyLinkedListNode oddTemp = oddListNode;

        while(start != null) {
            if(start.data % 2 == 0) {
                evenTemp.next = start;
                evenTemp = evenTemp.next;
                start = start.next;
            } else {
                oddTemp.next = start;
                oddTemp = oddTemp.next;
                start = start.next;
                oddTemp.next = null;
            }

        }
        evenTemp.next = oddListNode.next;
        return evenListNode.next;
    }
}
