package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class OccurenceOfInteger {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);

        int search_for = scanner.nextInt();

        SinglyLinkedList llist1 = new SinglyLinkedList();
        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist1.insertNode(llistItem);
        }

        System.out.println(count(search_for, llist1.head));

        scanner.close();
    }

    public static int count(int search_for, SinglyLinkedListNode sll) {
        // Write your code here
        int count = 0;
        while(sll != null) {
            if(sll.data == search_for) {
                count++;
            }
            sll = sll.next;
        }
        return count;
    }
}
