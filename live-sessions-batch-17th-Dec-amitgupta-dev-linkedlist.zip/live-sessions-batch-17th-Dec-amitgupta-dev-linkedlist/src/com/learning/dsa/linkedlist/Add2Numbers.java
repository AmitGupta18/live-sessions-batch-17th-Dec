package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class Add2Numbers {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist1 = new SinglyLinkedList();
        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist1.insertNode(llistItem);
        }

        SinglyLinkedList llist2 = new SinglyLinkedList();
        llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist2.insertNode(llistItem);
        }

        SinglyLinkedListNode resultListHead = addNumbers(llist1.head, llist2.head);

        SinglyLinkedList.printSinglyLinkedList(resultListHead);

        scanner.close();
    }

    public static SinglyLinkedListNode addNumbers(SinglyLinkedListNode start_one, SinglyLinkedListNode start_two) {
        SinglyLinkedList sumList = new SinglyLinkedList();
        int carry = 0;
        while(start_one != null && start_two != null) {
            int sum = start_one.data + start_two.data + carry;
            carry = sum / 10;
            sumList.insertNode(sum % 10);
            start_one = start_one.next;
            start_two = start_two.next;
        }

        while (start_one != null) {
            int sum = carry + start_one.data;
            carry = sum / 10;
            sumList.insertNode(sum % 10);
            start_one = start_one.next;
        }

        while (start_two != null) {
            int sum = carry + start_two.data;
            carry = sum / 10;
            sumList.insertNode(sum % 10);
            start_two = start_two.next;
        }

        if (carry != 0) {
            sumList.insertNode(carry);
        }

        return sumList.head;
    }
}
