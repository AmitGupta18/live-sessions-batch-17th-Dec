package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class CheckPalindrome {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }


        System.out.println(isPalindrome(llist.head));

        scanner.close();
    }

    private static boolean isPalindrome(SinglyLinkedListNode start) {
        SinglyLinkedListNode slow = start;
        SinglyLinkedListNode fast = start;

        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }


        if (fast != null) {
            slow = slow.next;
        }
        SinglyLinkedListNode second = slow;
        slow = null;


        SinglyLinkedListNode prev = null;

        while (second != null) {
            SinglyLinkedListNode temp = second.next;
            second.next = prev;
            prev = second;
            second = temp;
        }

        second = prev;
        while (second != null && start != null) {
            if (start.data != second.data) {
                return false;
            }
            start = start.next;
            second = second.next;
        }
        return second == null;
    }

    public static void printSinglyLinkedList(SinglyLinkedListNode node) {
        while (node != null) {
            System.out.println(node.data);
            node = node.next;
        }
    }
}
