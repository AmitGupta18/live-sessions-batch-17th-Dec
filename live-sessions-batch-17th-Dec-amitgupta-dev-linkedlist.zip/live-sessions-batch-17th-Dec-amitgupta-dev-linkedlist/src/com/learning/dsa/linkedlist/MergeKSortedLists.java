package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class MergeKSortedLists {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);

        int k =  scanner.nextInt();
        SinglyLinkedListNode[] arr = new SinglyLinkedListNode[k];
        for(int i = 0; i < k; i++) {
            SinglyLinkedList llist1 = new SinglyLinkedList();
            int llistCount = scanner.nextInt();
            for (int j = 0; j < llistCount; j++) {
                int llistItem = scanner.nextInt();
                llist1.insertNode(llistItem);
            }
            arr[i] = llist1.head;
        }

        SinglyLinkedListNode mergedListHead = mergeKLists(arr);

        SinglyLinkedList.printSinglyLinkedList(mergedListHead);

        scanner.close();
    }

    public static SinglyLinkedListNode mergeKLists(SinglyLinkedListNode[] lists) {
        return partition(lists, 0, lists.length-1);
    }

    public static SinglyLinkedListNode partition(SinglyLinkedListNode[]lists, int start, int end) {
        if (start > end) {
            return null;
        }
        if (start == end) {
            return lists[start];
        }

        int mid = (start + end)/ 2;
        SinglyLinkedListNode list1 = partition(lists, start, mid);
        SinglyLinkedListNode list2 = partition(lists, mid+1, end);
        return mergeTwoLists(list1, list2);
    }

    public static SinglyLinkedListNode mergeTwoLists(SinglyLinkedListNode list1, SinglyLinkedListNode list2) {
        if (list1 == null) {
            return list2;
        } else if (list2 == null) {
            return list1;
        }

        SinglyLinkedListNode head = new SinglyLinkedListNode(0);
        SinglyLinkedListNode curr = head;

        while(list1 != null && list2 != null) {
            if(list1.data <= list2.data) {
                curr.next = list1;
                list1 = list1.next;
            } else {
                curr.next = list2;
                list2 = list2.next;
            }
            curr = curr.next;
        }

        if(list1 != null) {
            curr.next = list1;
        } else {
            curr.next = list2;
        }

        return head.next;
    }
}
