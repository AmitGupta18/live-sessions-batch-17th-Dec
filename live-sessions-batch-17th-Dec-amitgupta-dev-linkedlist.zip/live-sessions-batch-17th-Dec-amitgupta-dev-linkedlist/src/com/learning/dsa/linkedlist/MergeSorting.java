package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class MergeSorting {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }
        SinglyLinkedListNode result = mergeSort(llist.head);

        SinglyLinkedList.printSinglyLinkedList(result);

        scanner.close();
    }

    private static SinglyLinkedListNode mergeSort(SinglyLinkedListNode start) {
        if(start == null || start.next == null) {
            return start;
        }
        SinglyLinkedListNode slow = start;
        SinglyLinkedListNode fast = start;

        while(fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }

        SinglyLinkedListNode temp = slow.next;
        slow.next = null;
        if (temp == null) {
            temp = start.next;
            start.next = null;
            return merge(start, temp);
        }
        SinglyLinkedListNode first = mergeSort(start);
        SinglyLinkedListNode second = mergeSort(fast);
        return merge(first, second);
    }

    private static SinglyLinkedListNode merge(SinglyLinkedListNode first, SinglyLinkedListNode second) {
        SinglyLinkedListNode head = new SinglyLinkedListNode(0);
        SinglyLinkedListNode temp = head;
        while(first != null && second != null) {
            if(first.data < second.data) {
                temp.next = first;
                first = first.next;
            } else {
                temp.next = second;
                second = second.next;
            }
            temp = temp.next;
        }

        if(first != null) {
            temp.next = first;
        } else if(second != null) {
            temp.next = second;
        }
        return head.next;
    }
}
