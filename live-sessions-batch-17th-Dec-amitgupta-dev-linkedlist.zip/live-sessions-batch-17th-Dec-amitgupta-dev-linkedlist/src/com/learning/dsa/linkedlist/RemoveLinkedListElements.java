package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class RemoveLinkedListElements {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }

        int valueToRemove = scanner.nextInt();

        removeElements(llist.head, valueToRemove);

        SinglyLinkedList.printSinglyLinkedList(llist.head);

        scanner.close();
    }

    public static SinglyLinkedListNode removeElements(SinglyLinkedListNode head, int val) {
        SinglyLinkedListNode curr = head;
        SinglyLinkedListNode prev = null;

        while (curr != null) {
            if (curr.data == val) {
                if (prev == null) {
                    head = curr.next;
                } else {
                    prev.next = curr.next;
                }
            } else {
                prev = curr;
            }
            curr = curr.next;
        }
        return head;
    }
}
