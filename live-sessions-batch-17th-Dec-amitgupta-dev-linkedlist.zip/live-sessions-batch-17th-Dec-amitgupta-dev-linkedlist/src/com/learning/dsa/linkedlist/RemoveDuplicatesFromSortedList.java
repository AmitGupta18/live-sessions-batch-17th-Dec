package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class RemoveDuplicatesFromSortedList {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }
        deleteDuplicates(llist.head);

        SinglyLinkedList.printSinglyLinkedList(llist.head);

        scanner.close();
    }

    private static SinglyLinkedListNode deleteDuplicates(SinglyLinkedListNode head) {
        SinglyLinkedListNode prev = head;
        if (head == null || head.next == null) {
            return head;
        }
        SinglyLinkedListNode curr = head.next;

        while(curr != null) {
            if(curr.data == prev.data) {
                prev.next = curr.next;
            } else {
                prev = curr;
            }
            curr = curr.next;
        }
        return head;
    }
}
