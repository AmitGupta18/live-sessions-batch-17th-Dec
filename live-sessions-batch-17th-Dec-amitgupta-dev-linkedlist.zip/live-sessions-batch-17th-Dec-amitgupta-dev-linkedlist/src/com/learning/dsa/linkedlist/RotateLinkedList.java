package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class RotateLinkedList {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }

        int k = scanner.nextInt();

        SinglyLinkedListNode llist_head = rotateLL(llist.head, k);

        printSinglyLinkedList(llist_head);

        scanner.close();
    }

    public static SinglyLinkedListNode rotateLL(SinglyLinkedListNode start, int k) {
        int n = 0;
        SinglyLinkedListNode head = start;
        while (head != null) {
            head = head.next;
            n++;
        }

        int rotation = k % n;

        head = start;
        SinglyLinkedListNode temp = head;
        while (rotation > 0) {
            temp = head;
            head = head.next;
            rotation--;
        }
        temp.next = null;

        temp = head;

        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = start;
        return head;
    }

    public static void printSinglyLinkedList(SinglyLinkedListNode node) {
        while (node != null) {
            System.out.println(node.data);
            node = node.next;
        }
    }
}
