package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class ReverseKLinkedList {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        int k = scanner.nextInt();
        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }
        SinglyLinkedListNode result = reverseKLL(llist.head, k);

        SinglyLinkedList.printSinglyLinkedList(result);

        scanner.close();
    }

    private static SinglyLinkedListNode reverseKLL(SinglyLinkedListNode start, int k) {
        if(start == null || start.next == null) {
            return start;
        }
        SinglyLinkedListNode second = start;

        for(int i = 1; i < k; i++) {
            second = second.next;
        }
        SinglyLinkedListNode next = second.next;
        second.next = null;

        SinglyLinkedListNode prev = reverse(start);
        start.next = reverseKLL(next, k);

        return prev;
    }

    private static SinglyLinkedListNode reverse(SinglyLinkedListNode start) {
        SinglyLinkedListNode curr = start;
        SinglyLinkedListNode prev = null;
        while(curr != null) {
            SinglyLinkedListNode temp = curr.next;
            curr.next =  prev;
            prev = curr;
            curr = temp;
        }
        return prev;
    }
}
