package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class RemoveNthNodeFromBack {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        System.out.println("Enter node idx to remove from back");
        int k = scanner.nextInt();

        System.out.println("Enter size of list");
        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }

        removeNNodeBack(llist.head, k);

        SinglyLinkedList.printSinglyLinkedList(llist.head);

        scanner.close();
    }

    public static SinglyLinkedListNode removeNNodeBack(SinglyLinkedListNode start, int k) {
        SinglyLinkedListNode first = start;
        SinglyLinkedListNode second = start;

        while (k >= 0 && second != null) {
            second = second.next;
            k--;
        }

        while (k >= 0) {
            first = first.next;
            k--;
            if (k < 0) {
                return first;
            }
        }

        while (second != null) {
            first = first.next;
            second = second.next;
        }

        if (first != null && first.next != null) {
            first.next = first.next.next;
        }

        return start;
    }
}
