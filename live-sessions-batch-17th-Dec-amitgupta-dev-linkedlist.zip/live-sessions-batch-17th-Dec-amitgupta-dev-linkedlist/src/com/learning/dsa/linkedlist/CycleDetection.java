package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class CycleDetection {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }

        System.out.println(hasCycle(llist.head));

        createCycle(llist);
        System.out.println(hasCycle(llist.head));
        System.out.println(cycleStart(llist.head).data);
        scanner.close();
    }

    private static void createCycle(SinglyLinkedList llist) {
        llist.tail.next = llist.head;
    }

    static boolean hasCycle(SinglyLinkedListNode head) {
        SinglyLinkedListNode slow = head;
        SinglyLinkedListNode fast = head;

        while(fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) {
                return true;
            }
        }
        return false;
    }

    private static SinglyLinkedListNode cycleStart(SinglyLinkedListNode head) {
        SinglyLinkedListNode slow = head;
        SinglyLinkedListNode fast = head;
        boolean hasCycle = false;

        while(fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) {
                hasCycle = true;
                slow = head;
                break;
            }
        }

        if (hasCycle) {
            while(slow != fast) {
                slow = slow.next;
                fast = fast.next;
            }
            return slow;
        }
        return null;
    }
}
