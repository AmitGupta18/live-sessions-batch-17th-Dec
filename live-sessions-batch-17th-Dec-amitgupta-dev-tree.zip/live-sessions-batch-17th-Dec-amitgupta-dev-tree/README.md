# live-sessions-batch-17th-Dec
The purpose of this repository is to check the progress of each and every candidate and to provide the students a platform to showcase as well as share their work with fellow classmates.
