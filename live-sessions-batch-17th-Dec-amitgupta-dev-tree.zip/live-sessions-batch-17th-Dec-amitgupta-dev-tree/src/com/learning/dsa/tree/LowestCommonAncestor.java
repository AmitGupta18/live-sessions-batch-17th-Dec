package com.learning.dsa.tree;

import com.learning.dsa.tree.def.BinaryTree;
import com.learning.dsa.tree.def.Node;

public class LowestCommonAncestor {
    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        Node root =tree.populateTree(new int[]{3,5,1,6,2,0,8,-1,-1,7,4});
        System.out.println(lca(root, 5, 4).data);
    }

    private static Node lca(Node root, int v1, int v2) {
        if(root == null || root.data == v1 || root.data == v2) {
            return root;
        }

        Node left = lca(root.left, v1, v2);
        Node right = lca(root.right, v1, v2);

        if(left == null) {
            return right;
        }
        if(right == null) {
            return left;
        }
        return root;
    }
}
