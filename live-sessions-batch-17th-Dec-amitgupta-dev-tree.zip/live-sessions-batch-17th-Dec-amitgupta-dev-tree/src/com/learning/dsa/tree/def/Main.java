package com.learning.dsa.tree.def;

public class Main {
    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        Node root = tree.populateTree(new int[] {1,2,3,-1,-1,5,6,-1,-1,-1,-1,7,8});
        System.out.println("Height of tree: "+ tree.height(root));

        System.out.println("BFS:");
        tree.bfs(root);

        System.out.println("DFS:");
        System.out.println("INORDER:");
        tree.dfs(root, "INORDER");

        System.out.println("PREORDER:");
        tree.dfs(root, "PREORDER");

        System.out.println("POSTORDER:");
        tree.dfs(root, "POSTORDER");
    }
}
