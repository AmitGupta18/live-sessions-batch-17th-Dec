package com.learning.dsa.tree.def;

public class Node {
    public int data;
    public Node left;
    public Node right;

    Node(int data) {
        this.data = data;
        left = null;
        right = null;
    }

    Node(int data, Node left, Node right) {
        this.data = data;
        this.left = left;
        this.right = right;
    }
}
