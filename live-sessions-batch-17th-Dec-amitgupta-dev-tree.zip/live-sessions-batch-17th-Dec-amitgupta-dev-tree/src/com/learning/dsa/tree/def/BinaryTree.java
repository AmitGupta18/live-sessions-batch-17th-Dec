package com.learning.dsa.tree.def;

import java.util.LinkedList;
import java.util.Queue;

public class BinaryTree {
    Node root;

    public Node populateTree(int[] arr) {
        this.root = insert(arr, 0);
        return root;
    }

    private Node insert(int[] arr, int i) {
        Node temp = null;
        if(i < arr.length && arr[i] >= 0) {
            temp = new Node(arr[i]);
            temp.left = insert(arr, 2*i+1);
            temp.right = insert(arr, 2*i+2);
        }
        return  temp;
    }

    public int height(Node root) {
        if(root == null) {
            return 0;
        }

        return maxDepth(root)-1;
    }

    private int maxDepth(Node root) {
        if (root == null) {
            return 0;
        }
        return 1+ Math.max(maxDepth(root.left),  maxDepth(root.right));
    }

    public void bfs(Node root) {
        if (root == null) {
            return;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);

        while(!queue.isEmpty()) {
            Node temp = queue.remove();

            if(temp.left != null) {
                queue.add(temp.left);
            }
            if(temp.right != null) {
                queue.add(temp.right);
            }
            System.out.println(temp.data);
        }
    }


    public void dfs(Node root, String order) {
        switch (order) {
            case "INORDER":
                dfsInorder(root);
                break;
            case "PREORDER":
                dfsPreorder(root);
                break;
            case "POSTORDER":
                dfsPostorder(root);
                break;
        }

    }

    private void dfsInorder(Node root) {
        if(root == null) {
            return;
        }

        dfsInorder(root.left);
        System.out.println(root.data);
        dfsInorder(root.right);
    }

    private void dfsPreorder(Node root) {
        if(root == null) {
            return;
        }

        System.out.println(root.data);
        dfsPreorder(root.left);
        dfsPreorder(root.right);
    }

    private void dfsPostorder(Node root) {
        if(root == null) {
            return;
        }

        dfsPostorder(root.left);
        dfsPostorder(root.right);
        System.out.println(root.data);
    }
}
