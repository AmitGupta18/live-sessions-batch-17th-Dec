package com.learning.dsa.tree;

import com.learning.dsa.tree.def.BinaryTree;
import com.learning.dsa.tree.def.Node;

public class CheckBTIsBST {
    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        Node root =tree.populateTree(new int[]{3,5,2,1,4,6});
        System.out.println(checkBST(root));
    }

    private static boolean checkBST(Node root) {
        int leftBoundary = Integer.MIN_VALUE, rightBoundary = Integer.MAX_VALUE;
        return checkBSTUtil(root, leftBoundary, rightBoundary);
    }

    private static boolean checkBSTUtil(Node root, int leftBoundary, int rightBoundary) {
        if(root.data > rightBoundary || root.data < leftBoundary) {
            return false;
        }

        return checkBSTUtil(root.left, leftBoundary, root.data) && checkBSTUtil(root.right, root.data, rightBoundary);
    }
}
