package com.learning.dsa.graphs;

import java.util.HashMap;
import java.util.Map;

import com.learning.dsa.graphs.def.Graph;
import com.learning.dsa.graphs.def.Node;

public class CloneGraph {
    public static void main(String[] args) {
        Graph graph = new Graph();
        graph.signUp("1");
        graph.signUp("2");
        graph.signUp("3");
        graph.signUp("4");

        graph.sendRequest("1", "2");
        graph.sendRequest("1", "4");
        graph.sendRequest("2", "3");
        graph.sendRequest("3", "4");

        graph.printGraph();
        Node node = cloneGraph(graph.getNodeByValue("1"));
        System.out.println(node);
    }

    private static Node cloneGraph(Node node) {
        if (node == null) {
            return null;
        }
        Map<Node, Node> cloneMap = new HashMap<>();
        return dfs(node, cloneMap);
    }

    private static Node dfs(Node node, Map<Node, Node> cloneMap) {
        if (cloneMap.containsKey(node)) {
            return cloneMap.get(node);
        }

        Node copy = new Node(node.getData());
        cloneMap.put(node, copy);
        for (Node friend: node.getConnections()) {
            copy.getConnections().add(dfs(friend, cloneMap));
        }
        return copy;
    }
}
