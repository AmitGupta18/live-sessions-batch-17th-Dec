package com.learning.dsa.graphs;

public class NumberOfIslands {
    public static void main(String[] args) {
        char[][] grid = new char[][]{
                {'1', '1', '0', '0', '0'},
                {'1', '1', '0', '0', '0'},
                {'0', '0', '1', '0', '0'},
                {'0', '0', '0', '1', '1'}
        };

        System.out.println(numIslands(grid));
    }

    private static int numIslands(char[][] grid) {
        int numIslands = 0;

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == '1') {
                    numIslands++;
                    checkAdjacent(grid, i, j);
                }
            }
        }

        return numIslands;
    }

    private static void checkAdjacent(char[][] grid, int i, int j) {
        if (i >= grid.length ||
                j >= grid[0].length ||
                i < 0 ||
                j < 0 ||
                grid[i][j] == '0') {
            return;
        }
        grid[i][j] = '0';

        // current grid val represents an island,
        // so even if adjacent values are also '1'  island count will not increase
        checkAdjacent(grid, i + 1, j);
        checkAdjacent(grid, i, j + 1);
        checkAdjacent(grid, i - 1, j);
        checkAdjacent(grid, i, j - 1);
    }
}
