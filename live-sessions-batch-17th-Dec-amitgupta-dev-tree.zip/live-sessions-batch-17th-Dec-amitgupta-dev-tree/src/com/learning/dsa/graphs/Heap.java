package com.learning.dsa.graphs;

import java.util.LinkedList;

public class Heap {
    private LinkedList<Integer> nodes = new LinkedList<>();

    private void insert(int num) {
        nodes.add(num);

        int currIdx = nodes.size() -1 ;
        int parentIdx = (currIdx -1)/ 2;

        while(parentIdx >= 0 && nodes.get(parentIdx) < num) {
            nodes.set(currIdx, nodes.get(parentIdx));
            nodes.set(parentIdx, num);
            currIdx = parentIdx;
            parentIdx = (currIdx -1)/ 2;
        }
    }

    private int extractMax() {
        int result = nodes.get(0);
        int lastIdx = nodes.size() - 1;

        nodes.set(0, nodes.get(lastIdx));
        nodes.remove(lastIdx);
        bubbleDown();
        return result;
    }

    private void bubbleDown() {
        int parentIdx = 0;
        while (true) {
            int leftIdx = parentIdx*2 + 1;
            int rightIdx = parentIdx*2 + 2;

            if (leftIdx >= nodes.size() || rightIdx >= nodes.size()){
                break;
            }

            int parentVal = nodes.get(parentIdx);
            if (nodes.get(leftIdx) > parentVal) {
                nodes.set(parentIdx, nodes.get(leftIdx));
                nodes.set(leftIdx, parentVal);
                parentIdx = leftIdx;
            } else if (nodes.get(rightIdx) > parentVal) {
                nodes.set(parentIdx, nodes.get(rightIdx));
                nodes.set(rightIdx, parentVal);
                parentIdx = rightIdx;
            } else {
                break;
            }
        }
    }

    private void print() {
        System.out.println(nodes);
    }

    public static void main(String[] args) {
        Heap heap = new Heap();
        heap.insert(20);
        heap.insert(15);
        heap.insert(10);
        heap.insert(5);
        heap.insert(4);
        heap.insert(3);
        heap.insert(2);

        heap.insert(30);
        heap.print();

        heap.extractMax();
        heap.print();
    }
}
