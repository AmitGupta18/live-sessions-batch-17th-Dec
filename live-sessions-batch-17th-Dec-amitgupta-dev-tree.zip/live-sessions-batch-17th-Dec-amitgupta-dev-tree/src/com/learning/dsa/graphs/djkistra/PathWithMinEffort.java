package com.learning.dsa.graphs.djkistra;

/*
https://leetcode.com/problems/path-with-minimum-effort/
 */

import java.util.PriorityQueue;

public class PathWithMinEffort {
    static class Node implements Comparable<Node>{
        Integer x, y, maxHeight;

        Node(int x, int y, int maxHeight) {
            this.x = x;
            this.y = y;
            this.maxHeight = maxHeight;
        }

        @Override
        public int compareTo(Node o) {
            return this.maxHeight - o.maxHeight;
        }
    }
    
    public static void main(String[] args) {
        int[][] heights = new int[][]{
                {1, 2, 2},
                {3, 8, 2},
                {5, 3, 5}};
        System.out.println(minimumEffortPath(heights));
    }

    static int minimumEffortPath(int[][] heights) {
        int[][] matrix = new int[heights.length][heights[0].length];

        for (int i = 0; i<heights.length; i++) {
            for (int j = 0; j < heights[0].length; j++) {
                matrix[i][j] = Integer.MAX_VALUE;
            }
        }

        return djkistraAlgo(heights, matrix, new int[]{0,0}, new int[]{heights.length-1, heights[0].length-1});
    }

    private static int djkistraAlgo(int[][] grid, int[][] matrix, int[] source, int[] destination) {
        int i = source[0], j = source[1];
        matrix[i][j] = 0;

        PriorityQueue<Node> queue = new PriorityQueue();
        queue.add(new Node(i, j, 0));


        while(!queue.isEmpty()) {
            Node temp = queue.poll();

            if(temp.x == destination[0] && temp.y == destination[1]) {
                return temp.maxHeight;
            }

            int[][] directions = new int[][]{{temp.x, temp.y+1}, {temp.x, temp.y-1}, {temp.x+1, temp.y}, {temp.x-1, temp.y}};

            for(int[] direction: directions) {
                int x = direction[0];
                int y = direction[1];
                if(checkBoundaries(x, y, grid.length, grid[0].length)) {
                    // calculate diff between curr and next mountain height and select max
                    int newMaxHeight = Math.max(temp.maxHeight, Math.abs(grid[temp.x][temp.y] - grid[x][y]));
                    if(newMaxHeight < matrix[x][y]) {
                        queue.add(new Node(x, y, newMaxHeight));
                        matrix[x][y] = newMaxHeight;
                    }
                }
            }
        }
        return -1;
    }

    private static boolean checkBoundaries(int i, int j, int m, int n) {
        return ((i >= 0) && (j >= 0) && (i<m) && (j<n));
    }
}
