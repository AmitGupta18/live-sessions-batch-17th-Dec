package com.learning.dsa.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TopKFrequentElements {
    public static void main(String[] args) {
        System.out.println(Arrays.toString(topKFrequent(new int[]{1,1,1,2,2,3}, 2)));
    }

    private static int[] topKFrequent(int[] nums, int k) {
        Map<Integer, Integer> freqMap = new HashMap<>();
        for(Integer num: nums) {
            if (freqMap.containsKey(num)) {
                freqMap.put(num, freqMap.get(num) + 1);
            } else {
                freqMap.put(num, 1);
            }
        }

        List<Integer>[] bucket = new ArrayList[nums.length + 1];
        for (Map.Entry<Integer, Integer> entry: freqMap.entrySet()) {
            int frequency = entry.getValue();
            if(bucket[frequency] == null) {
                bucket[frequency] = new ArrayList<>();
            }
            bucket[frequency].add(entry.getKey());
        }


        int[] result = new int[k];
        int count = 0;

        for(int i = bucket.length - 1; i >=0; i-- ) {
            if(bucket[i] != null) {
                for (Integer key: bucket[i]) {
                    result[count++] = key;

                    if (count == k) {
                        return result;
                    }
                }
            }
        }
        return result;
    }
}
