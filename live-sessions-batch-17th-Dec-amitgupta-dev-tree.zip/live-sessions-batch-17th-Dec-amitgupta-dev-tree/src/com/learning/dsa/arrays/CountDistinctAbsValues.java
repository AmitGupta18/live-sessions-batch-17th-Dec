package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.List;

public class CountDistinctAbsValues {
    public static void main(String[] args) {
        System.out.println(findDistinctCount(6, Arrays.asList(-1, -1, 0, 1, 1, 1)));
    }

    private static int findDistinctCount(int n, List<Integer> arr) {
        int left = 0, right = n-1;
        int count = n;

        while(left < right) {
            // remove duplicate count from left
            while(left != right && arr.get(left) == arr.get(left+1)) {
                left++;
                count--;
            }

            // remove duplicate count from right
            while(left != right && arr.get(right) == arr.get(right-1)) {
                right--;
                count--;
            }

            // no element left to process
            if (left == right) {
                return count;
            }

            int sum = arr.get(left) + arr.get(right);
            if (sum == 0) {
                // left and right abs values are same, decrease by 1
                count--;
                left++;
                right--;
            } else if (sum < 0) {
                // left element is unique, move to right
                left++;
            } else {
                // right element is unique, move to left
                right--;
            }
        }

        return count;
    }
}
