package com.learning.dsa.arrays;

public class ValidPalindrome5 {
    public static void main(String[] args) {
       System.out.println(isPalindrome("0P"));
    }

    private static boolean isPalindrome(String s) {
        int start = 0, end = s.length() - 1;

        while(start < end) {
           int startChar = Character.toLowerCase(s.charAt(start));
           int endChar = Character.toLowerCase(s.charAt(end));

           if(!((startChar <= 122 && startChar >= 97) ||  (startChar <= 57 && startChar >= 48))) {
               start++;
               continue;
           } else if(!((endChar <= 122 && endChar >= 97) ||  (endChar <= 57 && endChar >= 48))) {
               end--;
               continue;
           }
           if(startChar == endChar) {
               start++;
               end--;
           } else {
               return false;
           }
        }
        return true;
    }
}
