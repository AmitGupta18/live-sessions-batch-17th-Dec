package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.List;

public class ReverseArray25 {
    public static void main(String[] args) {
        System.out.println(reverse_an_array(5, Arrays.asList(1, 2, 3, 4, 5)));
    }

    public static List<Integer> reverse_an_array(int n, List<Integer> arr) {
        int first=0,  last = n-1;
        while(first <= last) {
            swap(arr, first++, last--);
        }
        return arr;
    }

    private static void swap(List<Integer> arr, int firstIdx, int secondIdx) {
        int temp = arr.get(firstIdx);
        arr.set(firstIdx, arr.get(secondIdx));
        arr.set(secondIdx, temp);
    }
}
