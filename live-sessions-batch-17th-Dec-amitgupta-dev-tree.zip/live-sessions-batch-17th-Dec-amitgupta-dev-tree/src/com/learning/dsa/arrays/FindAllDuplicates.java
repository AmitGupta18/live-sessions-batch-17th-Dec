package com.learning.dsa.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FindAllDuplicates {
    public static void main(String[] args) {
        System.out.println(findDuplicates(5, Arrays.asList(30, 10, 25, 11, 20)));
    }

    private static List<Integer> findDuplicates(int n, List<Integer> arr) {
        // Write your code here
        for (int i = 0; i < n; i++) {
            int index = Math.abs(arr.get(i)) - 1;
            if (arr.get(index) < 0) {
                arr.set(index, 0);
            } else {
                arr.set(index, -1 * arr.get(index));
            }
        }

        List<Integer> result = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (arr.get(i) == 0) {
                result.add(i + 1);
            }
        }
        return result;
    }
}
