package com.learning.dsa.arrays;

public class FindMissingAndRepeatingNum {
    public static void main(String[] args) {
        System.out.println(findTwoElement(new int[]{3,1,3}));
    }

    private static int[] findTwoElement(int[] arr) {
        // code here
        int[] result = new int[2];
        for (int i = 0; i < arr.length; i++) {
            int value = arr[i];
            int index = Math.abs(value) - 1;
            if (arr[index] < 0) {
                result[0] = Math.abs(arr[i]);
            }
            arr[index] = -1 * Math.abs(arr[index]);
        }

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > 0) {
                result[1] = i + 1;
                break;
            }
        }

        return result;
    }
}
