package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.List;

public class MoveZeroes6 {
    public static void main(String[] args) {
        System.out.println(moveZeroes(5, Arrays.asList(0,1,0,3,12)));
    }

    public static List<Integer> moveZeroes(int n, List<Integer> arr) {
        // Write your code here
        int k = 0;
        for(int i = 0; i < arr.size(); i++) {
            if(arr.get(i) !=0) {
                arr.set(k++, arr.get(i));
            }
        }

        while(k < arr.size()) {
            arr.set(k++, 0);
        }
        return arr;
    }
}
