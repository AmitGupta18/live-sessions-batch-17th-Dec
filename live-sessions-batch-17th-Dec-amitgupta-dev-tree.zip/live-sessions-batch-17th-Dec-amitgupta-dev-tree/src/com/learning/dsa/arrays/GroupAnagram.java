package com.learning.dsa.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class GroupAnagram {

    public static void main(String[] args) {
        System.out.println(groupAnagrams(new String[]{"bdddddddddd","bbbbbbbbbbc"}));
    }

    private static List<List<String>> groupAnagrams(String[] strs) {

        Map<String, List<String>> group = new HashMap<>();
        for (String str : strs) {
            String hash = getStringHash(str);

            if (group.containsKey(hash)) {
                group.get(hash).add(str);
            } else {
                group.put(hash, Stream.of(str).collect(Collectors.toList()));
            }
        }

        List<List<String>> result = new ArrayList<>();
        for (String hash : group.keySet()) {
            result.add(group.get(hash));
        }

        return result;
    }

    private static String getStringHash(String str) {
        char[] arr = str.toCharArray();
        Arrays.sort(arr);
        return String.valueOf(arr);
    }
}
