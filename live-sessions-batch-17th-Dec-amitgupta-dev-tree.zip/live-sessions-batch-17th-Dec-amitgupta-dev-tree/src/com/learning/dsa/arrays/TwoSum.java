package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TwoSum {
    public static void main(String[] args) {
        System.out.println(two_sum(Arrays.asList(1, 2, 3, 4, 5, 6), 3));
    }

    private static List<Integer> two_sum(List<Integer> arr, int target) {
        Map<Integer, Integer> operandIdxMap = new HashMap<>();
        for(int i = 0; i < arr.size(); i++) {
            if (operandIdxMap.containsKey(target - arr.get(i))) {
                return Arrays.asList(operandIdxMap.get(target - arr.get(i)), i);
            }
            operandIdxMap.put(arr.get(i), i);
        }
        return Collections.emptyList();
    }
}
