package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class LongestConsecutiveSequence {
    public static void main(String[] args) {
        int[] arr = new int[] {100,4,200,1,3,2};
        System.out.println(longestConsecutive(arr));
    }

    private static int longestConsecutive(int[] nums) {
        Set<Integer> numbers = Arrays.stream(nums).boxed().collect(Collectors.toSet());
        int maxLength = 0;
        for (int i = 0; i < nums.length; i++) {
            int length = 1;
            // identify if current element is start of sequence
            if (!numbers.contains(nums[i] - 1)) {
                int left = nums[i];
                // check if consecutive element is present
                while(numbers.contains(left + 1)) {
                    length++;
                    left++;
                }
            }
            maxLength = Math.max(length, maxLength);
        }
        return maxLength;
    }
}
