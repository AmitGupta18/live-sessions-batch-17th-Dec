package com.learning.dsa.recursion;

import java.util.ArrayList;
import java.util.List;

public class PermutationSequence {
    private static int[] fact_arr = new int[] {0, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880};
    public static void main(String[] args) {
        System.out.println(getPermutation(4, 12));
    }

    private static String getPermutation(int n, int k) {
        List<Integer> digits = new ArrayList<>();
        for(int i = 1; i <= n; i++) {
            digits.add(i);
        }

        return populateDigits(n, k, digits, "");
    }

    private static String populateDigits(int n, int k, List<Integer> digits, String result) {
        if (n == 1) {
            result += digits.get(0);
            return result;
        }

        // block size - number of permutations for most significant digit
        int blockSize = fact_arr[n-1];
        int index = k/blockSize;

        // edge case
        if (k%blockSize == 0) {
            index--;
        }

        result += digits.get(index);
        digits.remove(index);
        k = k - fact_arr[n-1]*index;
        return populateDigits(n-1, k, digits, result);
    }
}
