package com.learning.dsa.recursion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CombinationSumII {
    public static void main(String[] args) {
        combinationSum2(8, 7, Arrays.asList(10, 1, 2, 7, 6, 1, 5));
    }

    private static void combinationSum2(int target, int n, List<Integer> matrix) {
        List<List<Integer>> result = new ArrayList<>();
        createSubsequence1(Arrays.asList(1, 2, 3), new ArrayList<>(), 0, result);
        System.out.println("All subsequences: "+ result);

        result.clear();
        Collections.sort(matrix);
        createSubsequence2(matrix, target, new ArrayList<>(), 0, 0, result);
        System.out.println("All subsequences sum to a target: "+ result);
        System.out.println(result);
    }

    private static void createSubsequence1(List<Integer> matrix, List<Integer> bag, int i, List<List<Integer>> result) {
        if (i == matrix.size()) {
            result.add(new ArrayList<>(bag));
            return;
        }

        bag.add(matrix.get(i));
        createSubsequence1(matrix, bag, i + 1, result);
        bag.remove(bag.size() - 1);
        createSubsequence1(matrix, bag, i + 1, result);
    }

    private static void createSubsequence2(List<Integer> matrix, int target, List<Integer> bag, int sum, int i, List<List<Integer>> result) {
        if (sum > target) {
            return;
        }
        if (i == matrix.size()) {
            if (sum == target) {
                result.add(new ArrayList<>(bag));
            }
            return;
        }

        bag.add(matrix.get(i));
        createSubsequence2(matrix, target, bag, (sum + matrix.get(i)), i + 1, result);
        bag.remove(bag.size() - 1);

        while (i + 1 < matrix.size() && matrix.get(i) == matrix.get(i + 1)) {
            i++;
        }
        createSubsequence2(matrix, target, bag, sum, i + 1, result);
    }
}
