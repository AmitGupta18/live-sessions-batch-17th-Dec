package com.learning.dsa.recursion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PossibleExpression {
    public static void main(String[] args) {
        possibleExpressions(5, "105");
    }

    private static void possibleExpressions(int target, String number) {
        List<String> result = new ArrayList<>();
        createExpression(number, target, 0, "", 0l, 0l, result);
        System.out.println(result);
    }

    private static void createExpression(String number, int target, int idx, String curr_expr, long curr_val, long prev_num, List<String> result) {
        if (idx == number.length()) {
            if (curr_val == target) {
                result.add(curr_expr);
            }
            return;
        }

        for (int i = idx; i < number.length(); i++) {
            // ex: 123 -> 1, 12, 123 in each itr
            long curr_num = Long.valueOf(number.substring(idx, i + 1));

            if (idx == 0) { // only 1 operand is present so no operator can be added
                createExpression(number, target, i+1, curr_expr + curr_num, curr_val + curr_num, curr_num, result);
            } else {
                createExpression(number, target, i+1, curr_expr + "+" + curr_num, curr_val + curr_num, curr_num, result);
                createExpression(number, target, i+1, curr_expr + "-" + curr_num, curr_val - curr_num, -curr_num, result);
                //  value  = remove previous number and consider prevNum*currNum as addition of resultant value
                createExpression(number, target, i+1, curr_expr + "*" + curr_num, curr_val - prev_num + curr_num * prev_num, curr_num*prev_num, result);
            }

            // edge case - if number is 105 then we should not consider 1+05 since 05 is not a number
            if (number.charAt(idx) == '0') {
                break;
            }
        }
    }
}
