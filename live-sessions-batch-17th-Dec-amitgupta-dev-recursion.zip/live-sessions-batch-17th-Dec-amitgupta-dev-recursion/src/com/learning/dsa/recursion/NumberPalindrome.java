package com.learning.dsa.recursion;

public class NumberPalindrome {
    public static void main(String[] args) {
        int num = 12345;
        System.out.println(reverse(num));
    }

    private static int reverse(int num) {
        int reverseNum = 0;
        while (num != 0) {
            reverseNum = (reverseNum *10) + (num%10);
            num = num/10;
        }
        return reverseNum;
    }
}
