package com.learning.dsa.recursion;

import java.util.HashMap;
import java.util.Map;

public class Fibonacci19 {
    private static Map<Integer, Integer> fibMap = new HashMap<>();

    public static void main(String[] args) {
        System.out.println(fibonacci(6));
    }

    private static int fibonacci(int n) {
        if (n < 2){
            return n;
        }

        if (fibMap.containsKey(n)) {
            return fibMap.get(n);
        }

        int sum = fibonacci(n-1) + fibonacci(n-2);
        fibMap.put(n, sum);
        return sum;
    }
}
