package com.learning.dsa.recursion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class NQueens {
    public static void main(String[] args) {
        System.out.println(solveNQueens(4));
    }

    private static List<List<String>> solveNQueens(int n) {
        List<List<String>> result = new ArrayList<>();
        nQueens(n, 0, new ArrayList<>(), result);
        return result;
    }

    private static void nQueens(int n, int row, List<Integer> matrix, List<List<String>> result) {
        if(row == n) {
            generateBoard(n, matrix, result);
            return;
        }
        for(int col = 0; col <n; col++) {
            if(isValidPlace(row, col, matrix)) {
                matrix.add(col);
                nQueens(n, row+1, matrix, result);
                matrix.remove(matrix.size()-1);
            }
        }
    }

    private static boolean isValidPlace(int row, int col, List<Integer> matrix) {
        // check only till curr row, since matrix would be filled till here only
        for(int i = 0; i < row; i++) {
            if(matrix.get(i) == col) {
                return false;
            }
        }

        // check diagonal
        for(int i = 0; i < row; i++) {
            if(matrix.get(row-i-1) == col-i-1 || matrix.get(row-i-1) == col+i+1) {
                return false;
            }
        }

        return true;
    }

    private static void generateBoard(int n, List<Integer> matrix, List<List<String>> result) {
        List<String> temp = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            StringBuilder sb = new StringBuilder();
            int qPos = matrix.get(i);
            for(int j = 0; j < matrix.size(); j++) {
                if(j == qPos) {
                    sb.append("Q");
                } else {
                    sb.append(".");
                }
            }
            temp.add(sb.toString());
        }
        result.add(temp);
    }
}
