package com.learning.dsa.recursion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SubsetSum7 {
    public static void main(String[] args) {
        subsetSum(Arrays.asList(1, 2), 2);
    }

    private static List<Integer> subsetSum(List<Integer> nums, int n) {
        ArrayList<Integer> result = new ArrayList<>();
        createSubsets(nums, new ArrayList<>(), 0, result);
        Collections.sort(result);
        return result;
    }

    private static void createSubsets(List<Integer> nums, List<Integer> bag, int i, List<Integer> result) {
        if (i == nums.size()) {
            result.add(bag.stream().reduce(0, Integer::sum).intValue());
            return;
        }

        bag.add(nums.get(i));
        createSubsets(nums, bag, i+1, result);
        bag.remove(bag.size() - 1);
        createSubsets(nums, bag, i+1, result);
    }
}
