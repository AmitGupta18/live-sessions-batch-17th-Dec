package com.learning.dsa.recursion;

public class PowerOf2_5 {
    public static void main(String[] args) {
        System.out.println(powerOfInt(8));
    }

    private static boolean powerOfInt(int n) {
        if (n <= 0) {
            return false;
        }
        if (n == 1) {
            return true;
        }
        if (n % 2 == 0) {
            return powerOfInt(n / 2);
        }
        return false;
    }
}
