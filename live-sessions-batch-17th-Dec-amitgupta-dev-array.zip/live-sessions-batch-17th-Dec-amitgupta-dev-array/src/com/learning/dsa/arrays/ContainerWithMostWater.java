package com.learning.dsa.arrays;

public class ContainerWithMostWater {
    public static void main(String[] args) {
        System.out.println(maxArea(new int[]{1,8,6,2,5,4,8,3,7}));
    }

    private static int maxArea(int[] height) {
        int start = 0, end = height.length - 1;
        int maxArea = 0;
        while(start < end) {
            int minHeight = Math.min(height[start], height[end]);
            maxArea = Math.max(maxArea, minHeight*(end-start));
            if (height[start] > height[end]) {
                end--;
            } else {
                start++;
            }
        }
        return maxArea;
    }
}
