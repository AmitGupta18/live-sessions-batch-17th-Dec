package com.learning.dsa.arrays;

import java.util.ArrayList;

public class NumOfMatchingSubsequence {
    public static void main(String[] args) {
        System.out.println(numMatchingSubseq("abcde", new String[]{"a","bb","acd","ace"}));
    }

    private static int numMatchingSubseq(String s, String[] words) {
        // create a bucket of list, each index in bucket will represent a char (a-z)
        ArrayList<Node>[] buckets = new ArrayList[26];
        for(int i = 0; i < 26; i++) {
            buckets[i] = new ArrayList<>();
        }
        // set the word in bucket on the basis of first character
        for(String word: words) {
            char c = word.charAt(0);
            buckets[c-'a'].add(new Node(word, 0));
        }

        int ans = 0;
        for(int i=0; i < s.length(); i++) {
            char c = s.charAt(i);
            ArrayList<Node> currBucket = buckets[c-'a'];
            buckets[c-'a'] = new ArrayList<>();

            for(Node node: currBucket) {
                node.index++;
                // if index reaches end of word, it is a subsequence
                if(node.index == node.word.length()) {
                    ans++;
                } else {
                    buckets[node.word.charAt(node.index) - 'a'].add(node);
                }
            }
        }

        return ans;
    }
}

class Node {
    String word;
    int index;

    Node(String word, int index) {
        this.word = word;
        this.index = index;
    }

    @Override
    public String toString() {
        return "Node{" +
                "word='" + word + '\'' +
                ", index=" + index +
                '}';
    }
}
