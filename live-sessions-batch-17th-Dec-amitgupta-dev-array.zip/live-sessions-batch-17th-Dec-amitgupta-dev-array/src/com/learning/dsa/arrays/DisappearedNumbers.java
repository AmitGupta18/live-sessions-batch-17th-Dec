package com.learning.dsa.arrays;

import java.util.ArrayList;
import java.util.List;

public class DisappearedNumbers {
    public static void main(String[] args) {
        int[] nums = new int[]{4, 3, 2, 7, 8, 2, 3, 1};
        System.out.println(findDisappearedNumbers(nums));
    }

    public static List<Integer> findDisappearedNumbers(int[] nums) {
        List<Integer> disappearedNums = new ArrayList<>();
        for (int i = 0; i < nums.length; i++) {
            // get currValue
            int value = Math.abs(nums[i]);
            // find index using currValue
            int index = value - 1;
            // convert value to negative at above index
            nums[index] = -1 * Math.abs(nums[index]);
        }

        for (int i = 0; i < nums.length; i++) {
            if (nums[i] >= 0) {
                // if number at index is +ve, means this position didn't occur in array
                disappearedNums.add(i+1);
            }
        }
        return disappearedNums;
    }
}
