package com.learning.dsa.arrays;

public class MajorityElement {
    public static void main(String[] args) {
        System.out.println(majorityElement(new int[]{3,3,4}));
    }

    private static int majorityElement(int[] nums) {
        int majorityNum = nums[0], count = 0;
        for (int num : nums) {
            if (count <= 0) {
                majorityNum = num;
            }
            if (majorityNum == num) {
                count++;
            } else {
                count--;
            }
        }

        int majorityNumCount = 0;
        for (int num : nums) {
            if (num == majorityNum) {
                majorityNumCount++;
            }
        }

        if(majorityNumCount > (nums.length/2)) {
            return majorityNum;
        }
        return -1;
    }
}
