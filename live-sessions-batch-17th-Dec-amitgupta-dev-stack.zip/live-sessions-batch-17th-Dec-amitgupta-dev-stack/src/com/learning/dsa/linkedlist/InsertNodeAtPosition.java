package com.learning.dsa.linkedlist;

import java.io.IOException;
import java.util.Scanner;

public class InsertNodeAtPosition {

    private static final Scanner scanner = new Scanner(System.in);

    public static void printSinglyLinkedList(SinglyLinkedListNode node) {
        while (node != null) {
            System.out.println(node.data);
            node = node.next;
        }
    }


    public static SinglyLinkedListNode insertNodeAtPosition(SinglyLinkedListNode llist, int data, int position) {
        // Write your code here
        SinglyLinkedListNode newNode = new SinglyLinkedListNode(data);

        SinglyLinkedListNode node = llist;
        while(position > 1) {
            node = node.next;
            position--;
        }
        newNode.next = node.next;
        node.next = newNode;

        return llist;
    }


    public static void main(String[] args) throws IOException {
        SinglyLinkedList llist = new SinglyLinkedList();

        int llistCount = scanner.nextInt();

        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();

            llist.insertNode(llistItem);
        }

        int data = scanner.nextInt();

        int position = scanner.nextInt();

        SinglyLinkedListNode llist_head = insertNodeAtPosition(llist.head, data, position);

        printSinglyLinkedList(llist_head);

        scanner.close();
    }
}
