package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class ReorderLinkedList {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }


        reorderList(llist.head);

        SinglyLinkedList.printSinglyLinkedList(llist.head);

        scanner.close();
    }

    public static void reorderList(SinglyLinkedListNode head) {
        SinglyLinkedListNode slow = head;
        SinglyLinkedListNode fast = head.next;

        // find mid of list
        while(fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }

        // reverse second half of list
        SinglyLinkedListNode second = slow.next;
        // mark last element of first half of list as tail
        slow.next = null;
        SinglyLinkedListNode prev = null;

        while (second != null) {
            SinglyLinkedListNode temp = second.next;
            second.next = prev;
            prev = second;
            second = temp;
        }

        // reorder both the lists
        SinglyLinkedListNode first = head;
        second = prev;
        while (second != null) {
            SinglyLinkedListNode temp1 = first.next;
            SinglyLinkedListNode temp2 = second.next;

            first.next = second;
            second.next = temp1;
            first = temp1;
            second = temp2;
        }
    }
}
