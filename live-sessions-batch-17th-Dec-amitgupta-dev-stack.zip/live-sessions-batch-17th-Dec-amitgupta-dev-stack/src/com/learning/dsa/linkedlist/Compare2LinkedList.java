package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class Compare2LinkedList {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist1 = new SinglyLinkedList();
        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist1.insertNode(llistItem);
        }

        SinglyLinkedList llist2 = new SinglyLinkedList();
        llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist2.insertNode(llistItem);
        }

        System.out.println(compareLists(llist1.head, llist2.head));

        scanner.close();
    }

    static boolean compareLists(SinglyLinkedListNode head1, SinglyLinkedListNode head2) {
        SinglyLinkedListNode first = head1;
        SinglyLinkedListNode second = head2;

        while(first != null && second != null) {
            if(first.data != second.data) {
                return false;
            }
            first = first.next;
            second = second.next;
        }

        if(first==null && second == null) {
            return true;
        }
        return false;
    }
}
