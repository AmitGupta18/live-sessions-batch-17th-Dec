package com.learning.dsa.linkedlist;

import java.util.Scanner;

public class ReverseLinkedList {
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        SinglyLinkedList llist = new SinglyLinkedList();

        int llistCount = scanner.nextInt();
        for (int i = 0; i < llistCount; i++) {
            int llistItem = scanner.nextInt();
            llist.insertNode(llistItem);
        }


        SinglyLinkedListNode llist_head = reverseLinkedList(llist.head);

        printSinglyLinkedList(llist_head);

        scanner.close();
    }

    private static SinglyLinkedListNode reverseLinkedList(SinglyLinkedListNode head) {
        SinglyLinkedListNode curr = head;
        SinglyLinkedListNode prev = null;
        while(curr != null) {
            SinglyLinkedListNode temp = curr.next;
            curr.next = prev;
            prev = curr;
            curr = temp;
        }
        return prev;
    }

    public static void printSinglyLinkedList(SinglyLinkedListNode node) {
        while (node != null) {
            System.out.println(node.data);
            node = node.next;
        }
    }
}
