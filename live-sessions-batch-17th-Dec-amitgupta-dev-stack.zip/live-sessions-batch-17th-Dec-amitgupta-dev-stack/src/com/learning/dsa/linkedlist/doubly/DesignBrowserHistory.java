package com.learning.dsa.linkedlist.doubly;

public class DesignBrowserHistory {
    Node curr;

    public DesignBrowserHistory(String homepage) {
        curr = new Node(homepage);
    }

    public void visit(String url) {
        Node node = new Node(url);
        curr.next = node;
        node.prev = curr;
        curr = node;
    }

    public String back(int steps) {
        int count = 0;
        while (count < steps && curr.prev != null) {
            curr = curr.prev;
            count++;
        }
        return curr.value;
    }

    public String forward(int steps) {
        int count = 0;
        while (count < steps && curr.next != null) {
            curr = curr.next;
            count++;
        }
        return curr.value;
    }
}
