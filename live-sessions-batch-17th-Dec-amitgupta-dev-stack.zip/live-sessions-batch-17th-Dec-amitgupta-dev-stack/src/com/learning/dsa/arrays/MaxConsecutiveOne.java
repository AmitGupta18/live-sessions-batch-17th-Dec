package com.learning.dsa.arrays;

import java.util.Arrays;
import java.util.List;

public class MaxConsecutiveOne {
    public static void main(String[] args) {
        System.out.println(maxConsecutiveOne(Arrays.asList(1,1,0,1,1,1)));
    }

    public static int maxConsecutiveOne(List<Integer> arr) {
        int count = 0, max = 0;
        for (Integer num: arr) {
            if (num == 1) {
                count++;
            } else {
                max = Math.max(max, count);
                count = 0;
            }
        }
        return Math.max(max, count);
    }
}
