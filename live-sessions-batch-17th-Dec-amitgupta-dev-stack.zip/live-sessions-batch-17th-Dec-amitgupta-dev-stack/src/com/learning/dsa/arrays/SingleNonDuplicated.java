package com.learning.dsa.arrays;

public class SingleNonDuplicated {
    public static void main(String[] args) {
        System.out.println(singleNonDuplicate(new int[]{1,1,2,3,3,4,4,8,8}));
    }

    // same element pair should start at even index, if no unique element is present at left
    private static int singleNonDuplicate(int[] nums) {
        int left = 0;
        int right = nums.length - 1;

        while(left <= right) {
            int mid = left + (right - left)/ 2;

            if(mid > 0 && nums[mid] == nums[mid-1]) {
                if (mid%2 == 0) {
                    right = mid - 1;
                } else {
                    left = mid + 1;
                }
            } else if (mid < nums.length -1 && nums[mid] == nums[mid+1]) {
                // mid is at even index and it's value is same as next,
                // it means unique number is at right
                if(mid%2 == 0) {
                    left = mid + 1;
                } else {
                    right = mid - 1;
                }
            } else {
                return nums[mid];
            }
        }
        return -1;
    }
}
