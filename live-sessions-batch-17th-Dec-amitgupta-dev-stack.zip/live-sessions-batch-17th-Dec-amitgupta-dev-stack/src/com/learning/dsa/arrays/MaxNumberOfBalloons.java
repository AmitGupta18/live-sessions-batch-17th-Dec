package com.learning.dsa.arrays;

import java.util.HashMap;
import java.util.Map;

public class MaxNumberOfBalloons {
    public static void main(String[] args) {
        System.out.println(maxNumberOfBalloons("leetcode"));
    }

    public static int maxNumberOfBalloons(String text) {
        int result = text.length();
        Map<Character, Integer> textFrequency = countFrequency(text);
        Map<Character, Integer> balloonFrequency = countFrequency("balloon");

        if (!textFrequency.keySet().containsAll(balloonFrequency.keySet())){
            return 0;
        }
        for (Character ch: textFrequency.keySet()) {
            if (balloonFrequency.containsKey(ch)) {
                result = Math.min(result, textFrequency.get(ch)/balloonFrequency.get(ch));
            }
        }
        return result;
    }

    private static Map<Character, Integer> countFrequency(String text) {
        Map<Character, Integer> frequency = new HashMap<>();
        for (int i = 0; i < text.length(); i++) {
            if (frequency.containsKey(text.charAt(i))){
                frequency.put(text.charAt(i), frequency.get(text.charAt(i)) + 1);
            } else {
                frequency.put(text.charAt(i), 1);
            }
        }

        return frequency;
    }
}
