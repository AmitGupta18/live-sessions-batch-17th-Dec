package com.learning.dsa.stack;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

import com.learning.dsa.linkedlist.SinglyLinkedList;

public class QueueUsingStack {
    public static void main(String[] args) {
       /* INPUT
       10
        1 42
        2
        1 14
        3
        1 28
        3
        1 60
        1 78
        2
        2
        */
        final Scanner scanner = new Scanner(System.in);

        int numOps = scanner.nextInt();
        scanner.nextLine();
        String[] operations = new String[numOps];
        for (int i = 0; i < numOps; i++) {
            operations[i] = scanner.nextLine();
        }

        for (String op: operations) {
            switch (op) {
                case "2":
                    dequeue();
                    break;
                case "3":
                    printFirst();
                    break;
                default:
                    enqueue(op.split(" ")[1]);
            }
        }

        scanner.close();
    }

    static Stack<String> stack1 = new Stack<>();
    static Stack<String> stack2 = new Stack<>();
    private static void enqueue(String ele) {
        stack1.push(ele);
    }

    private static void printFirst() {
        if(stack1.isEmpty() && stack2.isEmpty()) {
            return;
        }
        if (stack2.isEmpty()) {
            while(!stack1.isEmpty()) {
                stack2.push(stack1.pop());
            }
        }
        System.out.println(stack2.peek());
    }

    private static void dequeue() {
        if(stack1.isEmpty() && stack2.isEmpty()) {
            return;
        }
        if (stack2.isEmpty()) {
            while(!stack1.isEmpty()) {
                stack2.push(stack1.pop());
            }
        }
        stack2.pop();
    }
}
