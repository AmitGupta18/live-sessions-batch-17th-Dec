package com.learning.dsa.stack;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class EqualStacks {
    public static void main(String[] args) {
        System.out.println(equalStacks(
                Arrays.asList(3,2,1,1,1),
                Arrays.asList(4,3,2),
                Arrays.asList(1,1,4,1)));
    }

    public static int equalStacks(List<Integer> h1, List<Integer> h2, List<Integer> h3) {
        Stack<Integer> s1 = fillStack(h1);
        Stack<Integer> s2 = fillStack(h2);
        Stack<Integer> s3 = fillStack(h3);

        while(!s1.isEmpty() && !s2.isEmpty() && !s3.isEmpty()) {
            int s1Ht = s1.peek();
            int s2Ht = s2.peek();
            int s3Ht = s3.peek();

            if(s1Ht == s2Ht && s2Ht == s3Ht) {
                return s1Ht;
            }

            if(s1Ht >= s2Ht && s1Ht >= s3Ht){
                s1.pop();
            }
            else if(s2Ht >= s1Ht && s2Ht >= s3Ht){
                s2.pop();
            }
            else if(s3Ht >= s1Ht && s3Ht >= s2Ht){
                s3.pop();
            }
        }

        return -1;
    }

    private static Stack<Integer> fillStack(List<Integer> list) {
        Stack<Integer> stack = new Stack<>();
        int prev = 0;
        for (int i = list.size()-1; i >=0; i--) {
            prev += list.get(i);
            stack.push(prev);
        }
        return stack;
    }
}
