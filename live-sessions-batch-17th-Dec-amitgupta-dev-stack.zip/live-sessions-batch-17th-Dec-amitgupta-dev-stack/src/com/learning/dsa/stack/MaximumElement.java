package com.learning.dsa.stack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class MaximumElement {
    public static void main(String[] args) {
       /* INPUT
            "1 91",
            "1 20",
            "2",
            "3",
            "1 26",
            "1 20",
            "2",
            "3",
            "1 97",
            "2",
            "3"
        */
        final Scanner scanner = new Scanner(System.in);

        int numOps = scanner.nextInt();
        scanner.nextLine();
        String[] operations = new String[numOps];
        for (int i = 0; i < numOps; i++) {
            operations[i] = scanner.nextLine();
        }

        System.out.println(getMax(Arrays.asList(operations)));

        scanner.close();
    }

    public static List<Integer> getMax(List<String> operations) {
        Stack<Integer> stack = new Stack<>();
        Stack<Integer> max = new Stack<>();
        List<Integer> result = new ArrayList<>();

        int temp = 0;
        for (String op: operations) {
            String[] opStr = op.split(" ");
            switch (opStr[0]) {
                case "2":
                     temp = stack.pop();
                    if(temp == max.peek()){
                        max.pop();
                    }
                    break;
                case "3":
                    if(!max.isEmpty()){
                        result.add(max.peek());
                    }
                    break;
                default:
                     temp = Integer.parseInt(opStr[1]);
                    stack.push(temp);
                    if(max.isEmpty() || temp >= max.peek()) {
                        max.push(temp);
                    }
            }
        }

        return result;
    }
}
